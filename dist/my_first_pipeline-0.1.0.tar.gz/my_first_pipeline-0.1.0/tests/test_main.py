from fastapi.testclient import TestClient
from src.main import app

client = TestClient(app)


def test_hello():
    response = client.get("/hello/World")
    assert response.status_code == 200
    assert response.json() == {"message": "Hello World"}
